package com.lucky.springemaildemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringemaildemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
